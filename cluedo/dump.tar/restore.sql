--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: check_solution(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.check_solution() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
	output	TEXT;
BEGIN
	DELETE FROM solution;
	CASE NEW.value 
		WHEN 'Jeremy Bowers' THEN output := 'Congrats, you found the murderer! But wait, there''s more... If you think you''re up for a challenge, try querying the interview transcript of the murderer to find the real villian behind this crime. If you feel especially confident in your SQL skills, try to complete this final step with no more than 2 queries.';
		WHEN 'Miranda Priestly' THEN output := 'Congrats, you found the brains behind the murder! Everyone in SQL City hails you as the greatest SQL detective of all time. Time to break out the champagne!';
		ELSE output := 'That''s not the right person. Try again!';
	END CASE;
	raise notice '%', output;
	RETURN coalesce(NEW, OLD);
END;
$$;


ALTER FUNCTION public.check_solution() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: crime_scene_report; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.crime_scene_report (
    date integer,
    type text,
    description text,
    city text
);


ALTER TABLE public.crime_scene_report OWNER TO postgres;

--
-- Name: drivers_license; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.drivers_license (
    id integer NOT NULL,
    age integer,
    height integer,
    eye_color text,
    hair_color text,
    gender text,
    plate_number text,
    car_make text,
    car_model text
);


ALTER TABLE public.drivers_license OWNER TO postgres;

--
-- Name: facebook_event_checkin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.facebook_event_checkin (
    person_id integer,
    event_id integer,
    event_name text,
    date integer
);


ALTER TABLE public.facebook_event_checkin OWNER TO postgres;

--
-- Name: get_fit_now_check_in; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.get_fit_now_check_in (
    membership_id text,
    check_in_date integer,
    check_in_time integer,
    check_out_time integer
);


ALTER TABLE public.get_fit_now_check_in OWNER TO postgres;

--
-- Name: get_fit_now_member; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.get_fit_now_member (
    id text NOT NULL,
    person_id integer,
    name text,
    membership_start_date integer,
    membership_status text
);


ALTER TABLE public.get_fit_now_member OWNER TO postgres;

--
-- Name: income; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.income (
    ssn integer NOT NULL,
    annual_income integer
);


ALTER TABLE public.income OWNER TO postgres;

--
-- Name: interview; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.interview (
    person_id integer,
    transcript text
);


ALTER TABLE public.interview OWNER TO postgres;

--
-- Name: person; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.person (
    id integer NOT NULL,
    name text,
    license_id integer,
    address_number integer,
    address_street_name text,
    ssn integer
);


ALTER TABLE public.person OWNER TO postgres;

--
-- Name: solution; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.solution (
    id integer,
    value text
);


ALTER TABLE public.solution OWNER TO postgres;

--
-- Data for Name: crime_scene_report; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.crime_scene_report (date, type, description, city) FROM stdin;
\.
COPY public.crime_scene_report (date, type, description, city) FROM '$$PATH$$/3351.dat';

--
-- Data for Name: drivers_license; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.drivers_license (id, age, height, eye_color, hair_color, gender, plate_number, car_make, car_model) FROM stdin;
\.
COPY public.drivers_license (id, age, height, eye_color, hair_color, gender, plate_number, car_make, car_model) FROM '$$PATH$$/3352.dat';

--
-- Data for Name: facebook_event_checkin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.facebook_event_checkin (person_id, event_id, event_name, date) FROM stdin;
\.
COPY public.facebook_event_checkin (person_id, event_id, event_name, date) FROM '$$PATH$$/3354.dat';

--
-- Data for Name: get_fit_now_check_in; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.get_fit_now_check_in (membership_id, check_in_date, check_in_time, check_out_time) FROM stdin;
\.
COPY public.get_fit_now_check_in (membership_id, check_in_date, check_in_time, check_out_time) FROM '$$PATH$$/3357.dat';

--
-- Data for Name: get_fit_now_member; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.get_fit_now_member (id, person_id, name, membership_start_date, membership_status) FROM stdin;
\.
COPY public.get_fit_now_member (id, person_id, name, membership_start_date, membership_status) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: income; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.income (ssn, annual_income) FROM stdin;
\.
COPY public.income (ssn, annual_income) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: interview; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.interview (person_id, transcript) FROM stdin;
\.
COPY public.interview (person_id, transcript) FROM '$$PATH$$/3355.dat';

--
-- Data for Name: person; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.person (id, name, license_id, address_number, address_street_name, ssn) FROM stdin;
\.
COPY public.person (id, name, license_id, address_number, address_street_name, ssn) FROM '$$PATH$$/3353.dat';

--
-- Data for Name: solution; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.solution (id, value) FROM stdin;
\.
COPY public.solution (id, value) FROM '$$PATH$$/3359.dat';

--
-- Name: drivers_license drivers_license_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.drivers_license
    ADD CONSTRAINT drivers_license_pkey PRIMARY KEY (id);


--
-- Name: get_fit_now_member get_fit_now_member_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.get_fit_now_member
    ADD CONSTRAINT get_fit_now_member_pkey PRIMARY KEY (id);


--
-- Name: income income_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT income_pkey PRIMARY KEY (ssn);


--
-- Name: person person_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_pkey PRIMARY KEY (id);


--
-- Name: solution check_solution; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER check_solution AFTER INSERT ON public.solution FOR EACH ROW EXECUTE FUNCTION public.check_solution();


--
-- Name: facebook_event_checkin facebook_event_checkin_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.facebook_event_checkin
    ADD CONSTRAINT facebook_event_checkin_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.person(id);


--
-- Name: get_fit_now_check_in get_fit_now_check_in_membership_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.get_fit_now_check_in
    ADD CONSTRAINT get_fit_now_check_in_membership_id_fkey FOREIGN KEY (membership_id) REFERENCES public.get_fit_now_member(id);


--
-- Name: get_fit_now_member get_fit_now_member_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.get_fit_now_member
    ADD CONSTRAINT get_fit_now_member_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.person(id);


--
-- Name: interview interview_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interview
    ADD CONSTRAINT interview_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.person(id);


--
-- Name: person person_license_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_license_id_fkey FOREIGN KEY (license_id) REFERENCES public.drivers_license(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

